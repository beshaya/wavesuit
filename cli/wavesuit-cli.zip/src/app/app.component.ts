import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  form: FormGroup;
  private server: string = "http://127.0.0.1:8000";

  painters = [
    {value: "hex", viewValue: "Hex"},
    {value: "line", viewValue: "Line"},
    {value: "pulse", viewValue: "Pulse"},
    {value: "rain", viewValue: "Rain"},
    {value: "fade", viewValue: "Fade"},
  ];

  constructor(
    private formBuilder: FormBuilder,
    private http: HttpClient) {
  }

  ngOnInit() {
    this.form = this.formBuilder.group({
      painter: ['pulse'],
      global_brightness: [0.5],
      speed: [0.5],
      color: this.colorGroup(),
      secondary_colors: this.formBuilder.array([
        this.colorGroup(), this.colorGroup()
      ]),
      fade: [0.8],
      bidirectional: [true]
    });
  }

  private colorGroup() {
    return this.formBuilder.group({
      r: [0],
      g: [0],
      b: [0],
    })
  }

  save() {
    console.log(this.form.value);
  }

  load() {
    this.http.get(this.server).subscribe((data: {[props: string]: any}) => {
      console.log(data);
    });
  }
}
