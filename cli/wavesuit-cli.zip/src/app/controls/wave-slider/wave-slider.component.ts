import { Component, OnInit } from '@angular/core';
import { MatSliderChange } from '@angular/material';

@Component({
  selector: 'wave-slider',
  templateUrl: './wave-slider.component.html',
  styleUrls: ['./wave-slider.component.css']
})
export class WaveSliderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}